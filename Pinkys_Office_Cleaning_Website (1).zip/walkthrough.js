const form = document.getElementById('walkthrough');
const statusMessage = form.querySelector('[role="status"]');
const submitButton = form.querySelector('button[type="submit"]');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (submitButton.disabled) return;

  if (location.protocol === 'file:' || ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname)) {
    statusMessage.textContent = 'This copy is a preview. To request a walkthrough now, call Angie at 419-345-8838.';
    return;
  }

  submitButton.disabled = true;
  statusMessage.textContent = 'Sending your request…';
  try {
    const response = await fetch('/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(new FormData(form)).toString()
    });
    if (!response.ok) throw new Error('Submission failed');
    form.reset();
    window.location.assign(form.action);
  } catch {
    statusMessage.textContent = 'Your request could not be confirmed. Please try again or call Angie at 419-345-8838.';
    submitButton.disabled = false;
  }
});
